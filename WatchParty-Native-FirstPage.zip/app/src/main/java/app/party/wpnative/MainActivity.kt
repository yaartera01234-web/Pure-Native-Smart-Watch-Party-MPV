package app.party.wpnative

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.media.ExifInterface
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URL

/**
 * PEHLA PAGE: Join screen (website-v61 wali #join-screen ka exact design).
 * Sirf design + inputs. Room join / chat / player baad ke steps mein.
 */
class MainActivity : Activity() {

    private lateinit var nameInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var towerBtn: Button

    private val towers = arrayOf("🗼 EMQX (tez!)", "🗼 HiveMQ", "🗼 tyckr")
    private var towerIndex = 0

    // Avatar state: null bitmap = letter (naam ka pehla harf), warna photo / cartoon
    private var avatarBitmap: Bitmap? = null
    private var avatarLetter: TextView? = null
    private var avatarImage: ImageView? = null
    private var avatarReq = 0
    private val REQ_PHOTO = 101

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildJoinScreen())
    }

    private fun buildJoinScreen(): View {
        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(hex("#0f0c29"), hex("#302b63"), hex("#24243e"))
        )

        val scroll = ScrollView(this)
        scroll.isFillViewport = true

        val card = LinearLayout(this).apply {
            clipChildren = false
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = roundBox(Color.argb(120, 12, 10, 28), Color.argb(70, 167, 139, 250), 24, 1)
        }

        // Logo (5 rangeeli bars) + title
        val logo = LogoView(this)
        card.addView(logo, lp(dp(44), dp(44)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        android.animation.ObjectAnimator.ofFloat(logo, "translationY", 0f, -dp(10).toFloat(), 0f).apply {
            duration = 2000
            repeatCount = android.animation.ObjectAnimator.INFINITE
            start()
        }
        card.addView(GradientText(this).apply {
            text = "Watch Party"
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 32f
            gravity = Gravity.CENTER
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5); bottomMargin = dp(5) })

        // Badge
        card.addView(TextView(this).apply {
            text = "Feel Special With Me 🥰 💗"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(hex("#f9a8d4"))
            setPadding(dp(18), dp(7), dp(18), dp(7))
            background = roundBox(Color.argb(46, 244, 114, 182), Color.argb(115, 244, 114, 182), 20, 1)
            // Website wala pink glow (box-shadow 0 0 18px rgba(244,114,182,.35)) — Android 9+ par colored shadow
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                elevation = dp(9).toFloat()
                outlineAmbientShadowColor = Color.argb(89, 244, 114, 182)
                outlineSpotShadowColor = Color.argb(89, 244, 114, 182)
            }
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5); bottomMargin = dp(12) })

        // Tagline
        card.addView(TextView(this).apply {
            text = "Doston ke sath YouTube & MP4 dekho + live chatting karo!"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(hex("#c4b5fd"))
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })

        // Avatar + buttons
        card.addView(buildAvatarPick(), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        // Name
        nameInput = styledEdit("Apna name likho...", 20, 17f)
        card.addView(nameInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        nameInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { renderAvatar() }
        })

        // Room
        roomInput = styledEdit("Room name... (doston se poocho!)", 20, 16f)
        card.addView(roomInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })

        // Tower (tap karke badlo)
        towerBtn = Button(this).apply {
            text = towers[towerIndex]
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 16f
            background = roundBox(Color.argb(200, 12, 10, 28), Color.argb(60, 255, 255, 255), 14, 2)
            setOnClickListener {
                towerIndex = (towerIndex + 1) % towers.size
                text = towers[towerIndex]
            }
        }
        card.addView(towerBtn, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) })

        // Theme bar (abhi sirf dikhawa; theme change baad mein)
        card.addView(buildThemeBar(), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })

        // Join button
        card.addView(Button(this).apply {
            text = "🥳 Party Me Enter Ho"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 18f
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(hex("#ff66bd"), hex("#a477ff"), hex("#55baff"))
            ).apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener {
                val n = nameInput.text.toString().trim()
                val r = roomInput.text.toString().trim()
                if (n.isEmpty() || r.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Naam aur room name likho", Toast.LENGTH_SHORT).show()
                } else {
                    // Room join agle step mein banega
                    Toast.makeText(this@MainActivity, "Room '$r' — join agle step mein", Toast.LENGTH_SHORT).show()
                }
            }
        }, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(12) })

        // Feature chips (3 qatarein)
        card.addView(chipFlow(listOf("▶️ YouTube", "🎞️ MP4/MP3", "📋 Playlist", "🖼️ DP", "↩️ Reply", "🔄 Sync", "🚪 Rooms")), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        renderAvatar()

        scroll.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), dp(8), dp(16), dp(24))
        })
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }

    private fun buildAvatarPick(): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        // Avatar circle: gradient + letter/emoji, uske upar photo/cartoon image (circle mein clip)
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(hex("#f472b6"), hex("#a78bfa"))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(3), Color.argb(77, 255, 255, 255))
            }
        }
        val letterView = TextView(this).apply {
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        avatarLetter = letterView
        val imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, outline: Outline) {
                    outline.setOval(0, 0, v.width, v.height)
                }
            }
            clipToOutline = true
        }
        avatarImage = imageView
        frame.addView(letterView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(imageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        col.addView(frame, lp(dp(58), dp(58)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(smallButton("📷 Photo", "#10b981", "#14b8a6") { openPhotoPicker() },
            lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        row.addView(smallButton("🎲 Cartoon", "#f59e0b", "#ef4444") { loadCartoon() },
            lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(8) })
        col.addView(row, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return col
    }

    private fun smallButton(label: String, c1: String, c2: String, onTap: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(Color.WHITE)
        setPadding(dp(16), 0, dp(16), 0)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(hex(c1), hex(c2)))
            .apply { cornerRadius = dp(20).toFloat() }
        setOnClickListener { onTap() }
    }

    /** Avatar dikhao: photo/cartoon hai to image, warna naam ka pehla harf. */
    private fun renderAvatar() {
        val bmp = avatarBitmap
        val letter = avatarLetter ?: return
        val img = avatarImage ?: return
        if (bmp != null) {
            img.setImageBitmap(bmp)
            img.visibility = View.VISIBLE
            letter.visibility = View.GONE
        } else {
            img.setImageDrawable(null)
            img.visibility = View.GONE
            letter.visibility = View.VISIBLE
            val name = if (::nameInput.isInitialized) nameInput.text.toString().trim() else ""
            letter.text = (name.firstOrNull()?.toString() ?: "😎").uppercase()
        }
    }

    private fun setAvatar(bmp: Bitmap?) {
        avatarBitmap = bmp
        renderAvatar()
    }

    private fun nextAvatarReq(): Int {
        avatarReq += 1
        return avatarReq
    }

    /** 📷 Photo: phone ki gallery khulti hai. */
    private fun openPhotoPicker() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, "Photo chuno"), REQ_PHOTO)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val myReq = nextAvatarReq()
            Thread {
                val bmp = try { decodePhoto(uri) } catch (e: Exception) { null }
                runOnUiThread {
                    if (myReq != avatarReq) return@runOnUiThread
                    if (bmp != null) setAvatar(bmp)
                    else Toast.makeText(this@MainActivity, "Photo load nahi hui", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    /** Photo ko chota karke, center se square crop karke, phone ki rotation theek karke return karta hai. */
    private fun decodePhoto(uri: android.net.Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
        if (maxSide <= 0) return null
        var sample = 1
        while (maxSide / (sample * 2) >= 256) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orient = try {
            contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val rot: Float = when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val upright = if (rot != 0f) {
            Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(rot) }, true)
        } else src

        val s = minOf(upright.width, upright.height)
        val x = (upright.width - s) / 2
        val y = (upright.height - s) / 2
        val crop = Bitmap.createBitmap(upright, x, y, s, s)
        return Bitmap.createScaledBitmap(crop, 256, 256, true)
    }

    /** 🎲 Cartoon: DiceBear fun-emoji ka random avatar (website wala hi style). */
    private fun loadCartoon() {
        val seed = java.util.UUID.randomUUID().toString().take(8)
        val url = "https://api.dicebear.com/9.x/fun-emoji/png?seed=$seed&size=256"
        val myReq = nextAvatarReq()
        Thread {
            val bmp = try { URL(url).openStream().use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
            runOnUiThread {
                if (myReq != avatarReq) return@runOnUiThread
                if (bmp != null) setAvatar(bmp)
                else Toast.makeText(this@MainActivity, "Cartoon load nahi hua, net check karo", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun buildThemeBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = roundBox(Color.argb(150, 12, 10, 28), Color.argb(56, 255, 255, 255), 14, 1)
        }
        bar.addView(TextView(this).apply { text = "🎨"; textSize = 16f; setPadding(0, 0, dp(9), 0) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = "Night Purple · Pink + Cyan"
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = "theme aur bubble badlo"
            textSize = 11f
            setTextColor(hex("#c4b5fd"))
        })
        bar.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // 3 rang ke dots
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in listOf("#ff66bd", "#a477ff", "#55baff")) {
            dots.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(hex(c)) }
            }, lp(dp(12), dp(12)).apply { rightMargin = dp(4) })
        }
        bar.addView(dots)
        bar.addView(TextView(this).apply { text = "›"; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, 0) })
        return bar
    }

    private fun chipFlow(items: List<String>): FlowLayout {
        val flow = FlowLayout(this)
        for (s in items) {
            val chip = TextView(this).apply {
                text = s
                textSize = 12f
                setTextColor(Color.WHITE)
                setSingleLine(true)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = roundBox(Color.argb(31, 255, 255, 255), Color.argb(38, 255, 255, 255), 20, 1)
            }
            flow.addView(chip, ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        return flow
    }

    private fun chipRow(items: List<String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        items.forEachIndexed { i, s ->
            row.addView(TextView(this).apply {
                text = s
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(12), dp(7), dp(12), dp(7))
                background = roundBox(Color.argb(26, 255, 255, 255), Color.argb(38, 255, 255, 255), 20, 1)
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        return row
    }

    private fun styledEdit(hint: String, maxLen: Int, size: Float): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(hex("#c4b5fd"))
        setTextColor(Color.WHITE)
        textSize = size
        gravity = Gravity.CENTER
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT
        filters = arrayOf<android.text.InputFilter>(android.text.InputFilter.LengthFilter(maxLen))
        setPadding(dp(18), 0, dp(18), 0)
        background = roundBox(Color.argb(200, 12, 10, 28), Color.argb(60, 255, 255, 255), 14, 2)
    }

    private fun roundBox(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(strokeDp), stroke)
        }

    private fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

    private fun hex(s: String): Int = Color.parseColor(s)

    // ---------- custom views ----------

    /** Website ka logo: 5 rangeeli bars, CSS wpWave jaisi wave animation. */
    inner class LogoView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bars = listOf(
            // x, y, height, color index
            floatArrayOf(2.4f, 8f, 13f, 0f), floatArrayOf(6.7f, 5f, 16f, 1f),
            floatArrayOf(11f, 2.6f, 18.4f, 2f), floatArrayOf(15.3f, 6.4f, 14.6f, 1f),
            floatArrayOf(19.6f, 9.6f, 11.4f, 0f)
        )
        private val colors = intArrayOf(hex("#54e8ff"), hex("#8b72ff"), hex("#ff5ebc"))
        private val delays = floatArrayOf(0f, 150f, 300f, 450f, 600f) // ms, website ke delays jaise
        private var t = 0f
        private val anim = android.animation.ValueAnimator.ofFloat(0f, 1800f).apply {
            duration = 1800
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            anim.start()
        }

        override fun onDetachedFromWindow() {
            anim.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = width / 24f
            val r = 1.35f * s
            for ((i, b) in bars.withIndex()) {
                // 0.9s ka forward + 0.9s ka wapas (alternate), ease-in-out
                val ph = (t + delays[i]) % 1800f
                val f = if (ph <= 900f) ph / 900f else (1800f - ph) / 900f
                val e = (1f - Math.cos(f * Math.PI).toFloat()) / 2f
                val scale = 0.45f + 0.55f * e
                val bottom = b[1] + b[2]
                val top = bottom - b[2] * scale
                paint.color = colors[b[3].toInt()]
                canvas.drawRoundRect(b[0] * s, top * s, (b[0] + 2.7f) * s, bottom * s, r, r, paint)
            }
        }
    }

    /** Gradient wala title (pink -> purple -> green, website jaisa). */
    inner class GradientText(ctx: Context) : TextView(ctx) {
        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            getPaint().shader = LinearGradient(
                0f, 0f, w.toFloat(), 0f,
                intArrayOf(hex("#ff66bd"), hex("#a477ff"), hex("#55baff")),
                null, Shader.TileMode.CLAMP
            )
        }
    }
}

/** Chips ko line-by-line wrap karta hai aur har line ko center mein rakhta hai (CSS flex-wrap jaisa). */
class FlowLayout(ctx: Context) : ViewGroup(ctx) {
    private val gap = (6 * resources.displayMetrics.density).toInt()

    override fun generateDefaultLayoutParams(): LayoutParams =
        MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(attrs: android.util.AttributeSet?): LayoutParams =
        MarginLayoutParams(context, attrs)

    override fun generateLayoutParams(p: LayoutParams?): LayoutParams =
        MarginLayoutParams(p)

    override fun checkLayoutParams(p: LayoutParams?): Boolean = p is MarginLayoutParams

    private fun childW(c: View): Int {
        val lp = c.layoutParams as MarginLayoutParams
        return c.measuredWidth + lp.leftMargin + lp.rightMargin
    }

    private fun childH(c: View): Int {
        val lp = c.layoutParams as MarginLayoutParams
        return c.measuredHeight + lp.topMargin + lp.bottomMargin
    }

    /** Lines mein baant do: har line ki (width, height, children). */
    private fun split(maxW: Int): List<Triple<Int, Int, List<View>>> {
        val out = mutableListOf<Triple<Int, Int, List<View>>>()
        var cur = mutableListOf<View>()
        var curW = 0
        var curH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            val cw = childW(c)
            if (cur.isNotEmpty() && curW + gap + cw > maxW) {
                out.add(Triple(curW, curH, cur))
                cur = mutableListOf()
                curW = 0
                curH = 0
            }
            if (cur.isNotEmpty()) curW += gap
            curW += cw
            curH = maxOf(curH, childH(c))
            cur.add(c)
        }
        if (cur.isNotEmpty()) out.add(Triple(curW, curH, cur))
        return out
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val inner = width - paddingLeft - paddingRight
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            measureChildWithMargins(c, MeasureSpec.makeMeasureSpec(inner, MeasureSpec.AT_MOST), 0,
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), 0)
        }
        val lines = split(inner)
        var h = paddingTop + paddingBottom
        for ((idx, line) in lines.withIndex()) {
            h += line.second
            if (idx > 0) h += gap
        }
        setMeasuredDimension(width, resolveSize(h, heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = (r - l) - paddingLeft - paddingRight
        var y = paddingTop
        for (line in split(maxW)) {
            var x = paddingLeft + (maxW - line.first) / 2
            for (c in line.third) {
                val lp = c.layoutParams as MarginLayoutParams
                val left = x + lp.leftMargin
                val top = y + lp.topMargin
                c.layout(left, top, left + c.measuredWidth, top + c.measuredHeight)
                x += childW(c) + gap
            }
            y += line.second + gap
        }
    }
}
