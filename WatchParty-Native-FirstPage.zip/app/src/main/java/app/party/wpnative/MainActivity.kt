package app.party.wpnative

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * PEHLA PAGE: Join screen (website-v61 wali #join-screen ka exact design).
 * Sirf design + inputs. Room join / chat / player baad ke steps mein.
 */
class MainActivity : Activity() {

    private lateinit var nameInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var towerBtn: Button

    private val towers = arrayOf("🗼 EMQX (tez!)", "🗼 HiveMQ", "🗼 tyckr")
    private var towerIndex = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildJoinScreen())
    }

    private fun buildJoinScreen(): View {
        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(hex("#0f0c29"), hex("#302b63"), hex("#24243e"))
        )

        val scroll = ScrollView(this)
        scroll.isFillViewport = true

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(26), dp(24), dp(26))
            background = roundBox(Color.argb(120, 12, 10, 28), Color.argb(70, 167, 139, 250), 24, 1)
        }

        // Logo (5 rangeeli bars) + title
        val logo = LogoView(this)
        card.addView(logo, lp(dp(50), dp(50)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        android.animation.ObjectAnimator.ofFloat(logo, "translationY", 0f, -dp(10).toFloat(), 0f).apply {
            duration = 2000
            repeatCount = android.animation.ObjectAnimator.INFINITE
            start()
        }
        card.addView(GradientText(this).apply {
            text = "Watch Party"
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 36f
            gravity = Gravity.CENTER
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5); bottomMargin = dp(5) })

        // Badge
        card.addView(TextView(this).apply {
            text = "Feel Special With Me 🥰 💗"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(hex("#f9a8d4"))
            setPadding(dp(18), dp(7), dp(18), dp(7))
            background = roundBox(Color.argb(46, 244, 114, 182), Color.argb(115, 244, 114, 182), 20, 1)
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5); bottomMargin = dp(12) })

        // Tagline
        card.addView(TextView(this).apply {
            text = "Doston ke sath YouTube & MP4 dekho + live chatting karo!"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(hex("#c4b5fd"))
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })

        // Avatar + buttons
        card.addView(buildAvatarPick(), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        // Name
        nameInput = styledEdit("Apna name likho...", 20, 17f)
        card.addView(nameInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))

        // Room
        roomInput = styledEdit("Room name... (doston se poocho!)", 20, 16f)
        card.addView(roomInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(10) })

        // Tower (tap karke badlo)
        towerBtn = Button(this).apply {
            text = towers[towerIndex]
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 16f
            background = roundBox(Color.argb(200, 12, 10, 28), Color.argb(60, 255, 255, 255), 14, 2)
            setOnClickListener {
                towerIndex = (towerIndex + 1) % towers.size
                text = towers[towerIndex]
            }
        }
        card.addView(towerBtn, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(10) })

        // Theme bar (abhi sirf dikhawa; theme change baad mein)
        card.addView(buildThemeBar(), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        // Join button
        card.addView(Button(this).apply {
            text = "🥳 Party Me Enter Ho"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 18f
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(hex("#ff66bd"), hex("#a477ff"), hex("#55baff"))
            ).apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener {
                val n = nameInput.text.toString().trim()
                val r = roomInput.text.toString().trim()
                if (n.isEmpty() || r.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Naam aur room name likho", Toast.LENGTH_SHORT).show()
                } else {
                    // Room join agle step mein banega
                    Toast.makeText(this@MainActivity, "Room '$r' — join agle step mein", Toast.LENGTH_SHORT).show()
                }
            }
        }, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(14) })

        // Feature chips (3 qatarein)
        card.addView(chipRow(listOf("▶️ YouTube", "🎞️ MP4/MP3", "📋 Playlist")), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        card.addView(chipRow(listOf("🖼️ DP", "↩️ Reply", "🔄 Sync")), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        card.addView(chipRow(listOf("🚪 Rooms")), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        scroll.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(20), dp(12), dp(20), dp(64))
        })
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }

    private fun buildAvatarPick(): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        // Avatar circle (gradient, emoji)
        val avatar = TextView(this).apply {
            text = "🙂"
            textSize = 30f
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(hex("#f472b6"), hex("#a78bfa"))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(3), Color.argb(77, 255, 255, 255))
            }
        }
        col.addView(avatar, lp(dp(66), dp(66)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(smallButton("📷 Photo", "#10b981", "#14b8a6"), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        row.addView(smallButton("🎲 Cartoon", "#f59e0b", "#ef4444"), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(8) })
        col.addView(row, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return col
    }

    private fun smallButton(label: String, c1: String, c2: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(Color.WHITE)
        setPadding(dp(16), 0, dp(16), 0)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(hex(c1), hex(c2)))
            .apply { cornerRadius = dp(20).toFloat() }
        setOnClickListener {
            Toast.makeText(this@MainActivity, "Photo/Cartoon avatar agle step mein", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildThemeBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = roundBox(Color.argb(150, 12, 10, 28), Color.argb(56, 255, 255, 255), 14, 1)
        }
        bar.addView(TextView(this).apply { text = "🎨"; textSize = 16f; setPadding(0, 0, dp(9), 0) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = "Night Purple · Pink + Cyan"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = "theme aur bubble badlo"
            textSize = 11f
            setTextColor(hex("#c4b5fd"))
        })
        bar.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // 3 rang ke dots
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in listOf("#ff66bd", "#a477ff", "#55baff")) {
            dots.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(hex(c)) }
            }, lp(dp(12), dp(12)).apply { rightMargin = dp(4) })
        }
        bar.addView(dots)
        bar.addView(TextView(this).apply { text = "›"; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, 0) })
        return bar
    }

    private fun chipRow(items: List<String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        items.forEachIndexed { i, s ->
            row.addView(TextView(this).apply {
                text = s
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(12), dp(7), dp(12), dp(7))
                background = roundBox(Color.argb(26, 255, 255, 255), Color.argb(38, 255, 255, 255), 20, 1)
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        return row
    }

    private fun styledEdit(hint: String, maxLen: Int, size: Float): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(hex("#c4b5fd"))
        setTextColor(Color.WHITE)
        textSize = size
        gravity = Gravity.CENTER
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT
        filters = arrayOf<android.text.InputFilter>(android.text.InputFilter.LengthFilter(maxLen))
        setPadding(dp(18), 0, dp(18), 0)
        background = roundBox(Color.argb(200, 12, 10, 28), Color.argb(60, 255, 255, 255), 14, 2)
    }

    private fun roundBox(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(strokeDp), stroke)
        }

    private fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

    private fun hex(s: String): Int = Color.parseColor(s)

    // ---------- custom views ----------

    /** Website ka logo: 5 rangeeli bars, CSS wpWave jaisi wave animation. */
    inner class LogoView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bars = listOf(
            // x, y, height, color index
            floatArrayOf(2.4f, 8f, 13f, 0f), floatArrayOf(6.7f, 5f, 16f, 1f),
            floatArrayOf(11f, 2.6f, 18.4f, 2f), floatArrayOf(15.3f, 6.4f, 14.6f, 1f),
            floatArrayOf(19.6f, 9.6f, 11.4f, 0f)
        )
        private val colors = intArrayOf(hex("#54e8ff"), hex("#8b72ff"), hex("#ff5ebc"))
        private val delays = floatArrayOf(0f, 150f, 300f, 450f, 600f) // ms, website ke delays jaise
        private var t = 0f
        private val anim = android.animation.ValueAnimator.ofFloat(0f, 1800f).apply {
            duration = 1800
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            anim.start()
        }

        override fun onDetachedFromWindow() {
            anim.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = width / 24f
            val r = 1.35f * s
            for ((i, b) in bars.withIndex()) {
                // 0.9s ka forward + 0.9s ka wapas (alternate), ease-in-out
                val ph = (t + delays[i]) % 1800f
                val f = if (ph <= 900f) ph / 900f else (1800f - ph) / 900f
                val e = (1f - Math.cos(f * Math.PI).toFloat()) / 2f
                val scale = 0.45f + 0.55f * e
                val bottom = b[1] + b[2]
                val top = bottom - b[2] * scale
                paint.color = colors[b[3].toInt()]
                canvas.drawRoundRect(b[0] * s, top * s, (b[0] + 2.7f) * s, bottom * s, r, r, paint)
            }
        }
    }

    /** Gradient wala title (pink -> purple -> green, website jaisa). */
    inner class GradientText(ctx: Context) : TextView(ctx) {
        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            getPaint().shader = LinearGradient(
                0f, 0f, w.toFloat(), 0f,
                intArrayOf(hex("#ff66bd"), hex("#a477ff"), hex("#55baff")),
                null, Shader.TileMode.CLAMP
            )
        }
    }
}
