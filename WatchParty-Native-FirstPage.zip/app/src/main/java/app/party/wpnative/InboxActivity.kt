package app.party.wpnative

import android.app.Activity
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.LayerDrawable
import android.view.animation.LinearInterpolator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * AGLA PAGE: Messages / Inbox (website-v61 wali #dm-sheet > #dm-view-inbox ka design).
 * Abhi demo data hai. Asli chats, friends aur E2E baad ke steps mein.
 */
class InboxActivity : Activity() {

    private data class Friend(
        val name: String,
        val last: String,
        val time: String,
        val online: Boolean,
        val unread: Boolean,
        val color: Int
    )

    // Demo data (asli dost list baad mein)
    private val demo = listOf(
        Friend("Dost 1", "Ok", "12:31 AM", false, false, hex("#f472b6")),
        Friend("Dost 2", "Ok", "Kal", true, true, hex("#38bdf8")),
        Friend("Dost 3", "Hi", "06/10", false, false, hex("#fb7185")),
        Friend("Dost 4", "Ok", "06/10", false, false, hex("#a78bfa"))
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun hex(s: String): Int = Color.parseColor(s)
    private fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildScreen())
    }

    private fun buildScreen(): View {
        val root = FrameLayout(this)
        // Website ka dm-sheet radial background
        root.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            setColors(intArrayOf(hex("#1a1a2e"), hex("#0f0b20"), hex("#050507")))
            setGradientCenter(0.5f, 0f)
            gradientRadius = resources.displayMetrics.heightPixels * 0.75f
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(buildHeader(), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(buildSearch(), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(2), dp(10), dp(14))
        }
        list.addView(TextView(this).apply {
            text = "CHATS"
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = 0.12f
            setTextColor(hex("#A78BFA"))
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(4), dp(10), 0, dp(7))
        })
        demo.forEach { list.addView(buildRow(it)) }

        val scroll = ScrollView(this).apply { addView(list) }
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(buildBottomBar(), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(12), 0, dp(12), dp(12))
        })

        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }

    private fun buildHeader(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundBox(Color.argb(8, 255, 255, 255), Color.argb(15, 255, 255, 255), 0, 1)
        }
        bar.addView(TextView(this).apply {
            text = "💬 Messages"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        bar.addView(squareBtn("👤+", gradient = true), lp(dp(40), dp(40)).apply { leftMargin = dp(6) })
        bar.addView(squareBtn("☰", gradient = true), lp(dp(40), dp(40)).apply { leftMargin = dp(6) })
        bar.addView(squareBtn("✕", gradient = false), lp(dp(40), dp(40)).apply { leftMargin = dp(6) })
        return bar
    }

    private fun squareBtn(label: String, gradient: Boolean): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (gradient) hex("#0d0716") else Color.WHITE)
        background = if (gradient) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(hex("#54e8ff"), hex("#8b72ff")))
                .apply { cornerRadius = dp(12).toFloat() }
        } else {
            roundBox(Color.argb(31, 255, 255, 255), Color.argb(0, 255, 255, 255), 12, 0)
        }
        setOnClickListener {
            Toast.makeText(this@InboxActivity, "Agle step mein", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildSearch(): View {
        val wrap = FrameLayout(this).apply { setPadding(dp(12), dp(9), dp(12), dp(6)) }
        val input = EditText(this).apply {
            hint = "Naam ya code se dhoondo..."
            setHintTextColor(hex("#8b84a8"))
            setTextColor(Color.WHITE)
            textSize = 12.5f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(12), 0, dp(12), 0)
            background = roundBox(Color.argb(15, 255, 255, 255), Color.argb(20, 255, 255, 255), 11, 1)
        }
        wrap.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        return wrap
    }

    private fun buildRow(f: Friend): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(14), dp(12))
            background = roundBox(
                if (f.unread) Color.argb(20, 139, 114, 255) else Color.argb(10, 255, 255, 255),
                if (f.unread) Color.argb(46, 139, 114, 255) else Color.argb(15, 255, 255, 255),
                16, 1
            )
            setOnClickListener {
                Toast.makeText(this@InboxActivity, "${f.name} ka chat agle step mein", Toast.LENGTH_SHORT).show()
            }
        }

        // Avatar (letter) + online dot
        val avatar = FrameLayout(this)
        avatar.addView(TextView(this).apply {
            text = f.name.first().toString().uppercase()
            textSize = 18f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(f.color) }
        }, FrameLayout.LayoutParams(dp(48), dp(48)))
        avatar.addView(View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (f.online) hex("#22c55e") else hex("#6b7280"))
                setStroke(dp(2), hex("#0f0b20"))
            }
        }, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.END or Gravity.BOTTOM))
        row.addView(avatar, lp(dp(48), dp(48)))

        // Naam + last message pill
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(TextView(this).apply {
            text = f.name
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            setSingleLine(true)
        })
        info.addView(TextView(this).apply {
            text = f.last
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(11), dp(4), dp(11), dp(4))
            background = if (f.unread) {
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(hex("#7c3aed"), hex("#a78bfa")))
                    .apply { cornerRadius = dp(12).toFloat() }
            } else {
                roundBox(Color.argb(60, 12, 10, 28), Color.argb(70, 255, 255, 255), 12, 1)
            }
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
        row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })

        // Time + lock
        val meta = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        meta.addView(TextView(this).apply {
            text = f.time
            textSize = 11f
            setTextColor(Color.argb(102, 255, 255, 255))
        })
        meta.addView(TextView(this).apply {
            text = "🔒"
            textSize = 13f
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
        row.addView(meta, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        return row.also {
            it.layoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }
    }

    /** Neeche ka nav: website #yp-bar ka copy (gradient, gloss, sheen, glow pill, glow icons, pulsing dot). */
    private fun buildBottomBar(): View {
        val frame = FrameLayout(this)
        val fillLayer = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(240, 60, 37, 100), Color.argb(245, 30, 16, 54))).apply {
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.argb(43, 255, 255, 255))
        }
        // Gloss: upar wali roshni (website ka ::before), background ki layer ke taur par
        val glossLayer = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
            Color.argb(56, 255, 255, 255), Color.argb(13, 255, 255, 255), Color.argb(0, 255, 255, 255))).apply {
            cornerRadius = dp(22).toFloat()
        }
        frame.background = LayerDrawable(arrayOf(fillLayer, glossLayer))
        frame.clipToOutline = true

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val partyDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(hex("#4ade80")) }
        }
        ObjectAnimator.ofFloat(partyDot, "alpha", 0.35f, 1f).apply {
            duration = 1500L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        row.addView(navTab("party", "Party", false, partyDot), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(navTab("chat", "Chat", true, null), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(navTab("call", "Call", false, null), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        frame.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Sheen: chamakti hui safed patti, website ki tarah har 5.2s mein ek baar guzarti hai
        val sheenW = dp(110)
        val sheenH = dp(72)
        val sheen = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                Color.argb(0, 255, 255, 255), Color.argb(66, 255, 255, 255),
                Color.argb(16, 255, 255, 255), Color.argb(0, 255, 255, 255)))
            rotation = 20f
            alpha = 0f
        }
        frame.addView(sheen, FrameLayout.LayoutParams(sheenW, sheenH))
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 5200L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val p = a.animatedFraction
                val s = ((p - 0.09f) / 0.35f).coerceIn(0f, 1f)
                sheen.translationX = -sheenW + s * (frame.width + sheenW).toFloat()
                sheen.alpha = if (p in 0.09f..0.44f) 0.92f else 0f
            }
            start()
        }

        return frame
    }

    private fun navTab(kind: String, label: String, active: Boolean, dot: View?): View {
        val tab = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(8), dp(2), dp(6))
            if (active) {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.argb(140, 196, 120, 255), Color.argb(117, 255, 96, 176))).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), Color.argb(77, 255, 255, 255))
                }
            }
            setOnClickListener {
                if (!active) Toast.makeText(this@InboxActivity, "$label agle step mein", Toast.LENGTH_SHORT).show()
            }
        }
        val iconBox = FrameLayout(this)
        iconBox.addView(NavIcon(kind, active), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        if (dot != null) {
            iconBox.addView(dot, FrameLayout.LayoutParams(dp(7), dp(7), Gravity.END or Gravity.TOP))
        }
        tab.addView(iconBox, LinearLayout.LayoutParams(dp(24), dp(24)))
        tab.addView(TextView(this).apply {
            text = label
            textSize = 10f
            gravity = Gravity.CENTER
            letterSpacing = 0.03f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (active) Color.WHITE else Color.argb(255, 156, 138, 194))
            if (active) setShadowLayer(dp(5).toFloat(), 0f, 0f, Color.argb(140, 255, 140, 200))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        return tab
    }

    /** Website ke 24x24 stroke icons (party / chat / call), active par glow. */
    private inner class NavIcon(private val kind: String, private val on: Boolean) : View(this@InboxActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val path = Path()
        private val rect = RectF()

        override fun onDraw(c: Canvas) {
            val s = width / 24f
            c.save()
            c.scale(s, s)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.7f
            paint.color = if (on) Color.WHITE else Color.argb(255, 156, 138, 194)
            if (on) paint.setShadowLayer(10f, 0f, 0f, Color.argb(190, 255, 120, 190)) else paint.clearShadowLayer()
            path.reset()
            when (kind) {
                "party" -> {
                    rect.set(3f, 5f, 21f, 19f)
                    c.drawRoundRect(rect, 3.4f, 3.4f, paint)
                    path.moveTo(10.2f, 9.4f); path.lineTo(14.8f, 12f); path.lineTo(10.2f, 14.6f); path.close()
                    paint.style = Paint.Style.FILL
                    c.drawPath(path, paint)
                }
                "chat" -> {
                    path.moveTo(20.2f, 11.7f)
                    path.cubicTo(20.2f, 15.7f, 16.5f, 18.9f, 11.9f, 18.9f)
                    path.cubicTo(10.9f, 18.9f, 9.9f, 18.7f, 9.0f, 18.4f)
                    path.lineTo(4.6f, 20f)
                    path.lineTo(5.8f, 16.3f)
                    path.cubicTo(3.9f, 14.9f, 3.6f, 13.3f, 3.6f, 11.7f)
                    path.cubicTo(3.6f, 7.7f, 7.3f, 4.5f, 11.9f, 4.5f)
                    path.cubicTo(16.5f, 4.5f, 20.2f, 7.7f, 20.2f, 11.7f)
                    path.close()
                    c.drawPath(path, paint)
                }
                else -> {
                    path.moveTo(6.4f, 3.6f); path.lineTo(9.3f, 3.6f); path.lineTo(10.7f, 7.4f); path.lineTo(8.8f, 8.8f)
                    path.cubicTo(9.6f, 11.2f, 12.8f, 14.4f, 15.2f, 15.2f)
                    path.lineTo(16.6f, 13.3f); path.lineTo(20.4f, 14.7f); path.lineTo(20.4f, 17.6f)
                    path.cubicTo(20.4f, 18.9f, 19.4f, 19.9f, 18.3f, 19.5f)
                    path.cubicTo(14f, 19.5f, 4.5f, 10f, 4.5f, 5.7f)
                    path.cubicTo(4.5f, 4.6f, 5.3f, 3.6f, 6.4f, 3.6f)
                    path.close()
                    c.drawPath(path, paint)
                }
            }
            c.restore()
        }
    }

    private fun roundBox(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
        }
}
